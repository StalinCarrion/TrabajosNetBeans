package Modelo;

import java.util.*;

/**
 * 
 */
public class Persona {

    public String Cedula;
    public String Nombres;
    public String Apellidos;

    public Persona() {
    }

    public Persona(String Cedula, String Nombres, String Apellidos) {
        this.Cedula = Cedula;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
    }


}