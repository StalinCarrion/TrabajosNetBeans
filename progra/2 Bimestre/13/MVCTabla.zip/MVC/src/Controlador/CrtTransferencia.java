/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import Modelo.Cuenta;
import Modelo.Transferencia;
import Modelo.DataCuenta;
import Modelo.DataTransferencia;
import Vista.frmTransferencia;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author UTPL
 */
public class CrtTransferencia implements ActionListener, MouseListener {

    private Cuenta modCuenta;

    private Transferencia mod;
    Cliente modCliente = new Cliente();
    CrtClientes modLog = new CrtClientes();
    private DataTransferencia modC;
    private frmTransferencia frm;

    public CrtTransferencia(Transferencia mod, DataTransferencia modC, frmTransferencia frm) {
        this.mod = mod;
        this.modC = modC;
        this.frm = frm;
        this.frm.jBBuscar.addActionListener(this);
        this.frm.jBtransferir.addActionListener(this);
        this.frm.jTCuenta1.addMouseListener(this);
        this.frm.jTCuenta2.addMouseListener(this);

    }

    public void Iniciar() {
        frm.setTitle("Transferencia");
        frm.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frm.jBBuscar) {
            Cliente objClie = new Cliente();
            if (BuscarCuentaCliente()) {

                System.out.println("ok");
                JOptionPane.showMessageDialog(null, "Registro encontrado");
                ArrayList<Cuenta> ArrayCuentas = new ArrayList<Cuenta>();
                ArrayCuentas = modCliente.getCuenta();
                DefaultTableModel modelo = new DefaultTableModel();
                modelo.addColumn("Numero");
                modelo.addColumn("Tipo");
                modelo.addColumn("Saldo");
                modelo.addColumn("Id del Oficial");

                for (Cuenta cuenta : ArrayCuentas) {
                    Object[] fila = new Object[4];
                    fila[0] = cuenta.getNumero();
                    fila[1] = cuenta.getTipo();
                    fila[2] = cuenta.getSaldo();
                    fila[3] = cuenta.getIdOficial();
                    modelo.addRow(fila);
                }
                frm.jTCuenta1.setModel(modelo);
                frm.jTCuenta2.setModel(modelo);
            } else {
                JOptionPane.showMessageDialog(null, "EL cliente no existe");
            }

        }

    }

    //sobre las tablas
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == frm.jTCuenta1) {
            int row = frm.jTCuenta1.getSelectedRow();
            //int column = (int) jTCuenta1.getSelectedColumn();
            //String strValor = (String) jTCuenta1.getModel().getRowCount(row);
            String aux = frm.jTCuenta1.getValueAt(row, 0).toString();
            frm.jLbl2.setText(aux);
        }
        
        if (e.getSource() == frm.jTCuenta2) {
            int row = (int) frm.jTCuenta2.getSelectedRow();
            //int column = (int) jTCuenta1.getSelectedColumn();
            //String strValor = (String) jTCuenta1.getModel().getRowCount(row);
            String aux = frm.jTCuenta2.getValueAt(row, 0).toString();
            frm.jLbl1.setText(aux);

        }
    }


    public boolean BuscarCuentaCliente() {
        modCliente = modLog.BuscarCliente2(frm.jTCedula.getText());
        System.out.println("que hay " + modCliente);
        if (modCliente.getDireccion() != null) //0 se crea con el objeto vacio
        {
            return true;
        } else {
            return false;
        }
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }
//    public boolean RegistrarTransaccion(Transaccion ObjTra, int tipo) {
//        DataTransaccion ObjDatTra = new DataTransaccion();
//        DataCuenta ObjDatCue = new DataCuenta();
//        boolean bandera = true;
//        if (tipo == 2) { //retiro
//            if (ObjTra.getValor() < ObjTra.getCuenta().getSaldo()) {
//                ObjTra.getCuenta().setSaldo(ObjTra.getCuenta().getSaldo() - ObjTra.getValor());
//                ObjDatTra.RegistrarTransaccion(ObjTra);
//                ObjDatCue.ActualizarSaldo(ObjTra.getCuenta());
//
//                bandera = true;
//            } else {
//                bandera = false;
//            }
//        }
//        if (tipo == 1) {
//            ObjTra.getCuenta().setSaldo(ObjTra.getCuenta().getSaldo() + ObjTra.getValor());
//            ObjDatTra.RegistrarTransaccion(ObjTra);
//            ObjDatCue.ActualizarSaldo(ObjTra.getCuenta());
//            bandera = true;
//        }
//        return bandera;
//    }
//
//    public String GenerarNumeroTransaccion() {
//        DataTransaccion ObjDatTra = new DataTransaccion();
//        Transaccion ObjTra = new Transaccion();
//        ObjTra = ObjDatTra.BuscarIdTransaccion();
//        int calculo = Integer.parseInt(ObjTra.getNumero()) + 1;
//        String auxNum = "";
//        if (calculo <= 9) {
//            auxNum = "00" + String.valueOf(calculo);
//        }
//        if (calculo >= 10 && calculo <= 99) {
//            auxNum = "0" + String.valueOf(calculo);
//        }
//        if (calculo >= 100 && calculo <= 999) {
//            auxNum = String.valueOf(calculo);
//        }
//        return auxNum;
//    }
}
