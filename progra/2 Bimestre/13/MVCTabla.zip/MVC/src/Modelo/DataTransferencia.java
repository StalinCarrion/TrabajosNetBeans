/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Modelo.Cajero;
import Modelo.Transferencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author UTPL
 */
public class DataTransferencia extends Conexion {
    
    public boolean BuscarClienteB(Cliente clie) {   
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM cliente WHERE Cedula=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, clie.getCedula());
            rs = ps.executeQuery();
            if (rs.next()) {
                clie.setCedula(rs.getString("Cedula"));
                clie.setNombres(rs.getString("Apellidos"));
                clie.setApellidos(rs.getString("Nombres"));
                clie.setDireccion(rs.getString("Direccion"));
                //ObjCli.setIdCliente(rs.getInt("idCliente"));
                return true;

            }
            return false;

        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
//    public void RegistrarTransaccion(Transaccion ObjTra){
//        insert 
//    }

//    public boolean RegistrarTransaccion(Transferencia ObjTra) {
//
//        PreparedStatement ps = null;
//        Connection con = getConexion();
//        String sql = "INSERT INTO transaccion (Numero, Fecha, Valor, Tipo,Cajero_idCajero,Cuenta_idCuenta) "
//                + "VALUES (?,?,?,?,?,?)";
//        try {
//            ps = con.prepareStatement(sql);
//            ps.setString(1, ObjTra.getNumero());
//            ps.setDate(2, ObjTra.getFecha());
//            ps.setDouble(3, ObjTra.getValor());
//            ps.setDouble(4, ObjTra.getTipo());
//            ps.setInt(5, ObjTra.getCajero().getCaja());
//            ps.setInt(6,ObjTra.getCuenta().getIdCuenta());
//            ps.execute();
//            return true;
//        } catch (Exception e) {
//            System.err.println(e);
//            return false;
//        } finally {
//            try {
//                con.close();
//            } catch (SQLException e) {
//                System.err.println(3);
//            }
//        }
//    }
//    public Transaccion BuscarIdTransaccion(){
//        Transaccion ObjTra = new Transaccion();
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//        Connection con = getConexion();
//        String sql = "SELECT MAX(idTransaccion) AS idTransaccion FROM transaccion";
//
//        try {
//            ps = con.prepareStatement(sql);
//            rs = ps.executeQuery();
//            if (rs.next()) {
//                ObjTra.setNumero(rs.getString("idTransaccion"));
//
//            }
//            return ObjTra;
//        } catch (Exception e) {
//            System.err.println(e);
//            return ObjTra;
//        } finally {
//            try {
//                con.close();
//            } catch (SQLException e) {
//                System.err.println(3);
//            }
//        }
//    }
}
