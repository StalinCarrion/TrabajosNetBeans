package Modelo;


import java.util.*;

/**
 * 
 */
public class Transferencia {
    public int Numero;
    public Date Fecha;
    public double valor;
    public String Observacion;
    public ArrayList<Cuenta> cuenta;
    public CuentaAutorizada CuentaAutorizada;

    public Transferencia() {
    }

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getObservacion() {
        return Observacion;
    }

    public void setObservacion(String Observacion) {
        this.Observacion = Observacion;
    }

    public ArrayList<Cuenta> getCuenta() {
        return cuenta;
    }

    public void setCuenta(ArrayList<Cuenta> cuenta) {
        this.cuenta = cuenta;
    }

   

    public CuentaAutorizada getCuentaAutorizada() {
        return CuentaAutorizada;
    }

    public void setCuentaAutorizada(CuentaAutorizada CuentaAutorizada) {
        this.CuentaAutorizada = CuentaAutorizada;
    }
    
    

}