package Clases;


import java.util.*;

/**
 * 
 */
public class CuentaAutorizada {

    private Date FechaAutorizacion;
    public Cuenta cuentas;
    public Cliente clientes;

    public CuentaAutorizada() {
    }



}