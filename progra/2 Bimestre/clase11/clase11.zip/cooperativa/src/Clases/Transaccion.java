package Clases;


import java.util.*;

/**
 * 
 */
public class Transaccion {

    public int Numero;
    public Date Fecha;
    private double valor;
    public int Tipo;
    public Cuenta cuenta;
    public Cajero cajero;

    public Transaccion() {
    }

   
}