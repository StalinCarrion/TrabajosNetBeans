package Clases;


import java.util.*;

/**
 * 
 */
public class Transferencia {
    public int Numero;
    public Date Fecha;
    public double valor;
    public String Observacion;
    public Cuenta cuenta;
    public CuentaAutorizada CuentaAutorizada;

    public Transferencia() {
    }

}