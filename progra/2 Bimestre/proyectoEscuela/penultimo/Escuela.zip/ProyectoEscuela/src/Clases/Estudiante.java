/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Estudiante {
   String NombreEstudiante;
   String ApellidoEstudiante;
   String CedulaEstudiante;
   String DireccionEstudiante;
   int EdadEstudiante;
   int idRepresentante;

    public Estudiante() {
    }

    public String getNombreEstudiante() {
        return NombreEstudiante;
    }

    public void setNombreEstudiante(String NombreEstudiante) {
        this.NombreEstudiante = NombreEstudiante;
    }

    public String getApellidoEstudiante() {
        return ApellidoEstudiante;
    }

    public void setApellidoEstudiante(String ApellidoEstudiante) {
        this.ApellidoEstudiante = ApellidoEstudiante;
    }

    public String getCedulaEstudiante() {
        return CedulaEstudiante;
    }

    public void setCedulaEstudiante(String CedulaEstudiante) {
        this.CedulaEstudiante = CedulaEstudiante;
    }

    public String getDireccionEstudiante() {
        return DireccionEstudiante;
    }

    public void setDireccionEstudiante(String DireccionEstudiante) {
        this.DireccionEstudiante = DireccionEstudiante;
    }

    public int getEdadEstudiante() {
        return EdadEstudiante;
    }

    public void setEdadEstudiante(int EdadEstudiante) {
        this.EdadEstudiante = EdadEstudiante;
    }

    public int getIdRepresentante() {
        return idRepresentante;
    }

    public void setIdRepresentante(int idRepresentante) {
        this.idRepresentante = idRepresentante;
    }

    public Estudiante(String NombreEstudiante, String ApellidoEstudiante, String CedulaEstudiante, String DireccionEstudiante, int EdadEstudiante, int idRepresentante) {
        this.NombreEstudiante = NombreEstudiante;
        this.ApellidoEstudiante = ApellidoEstudiante;
        this.CedulaEstudiante = CedulaEstudiante;
        this.DireccionEstudiante = DireccionEstudiante;
        this.EdadEstudiante = EdadEstudiante;
        this.idRepresentante = idRepresentante;
    }

}
