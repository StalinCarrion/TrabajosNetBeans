
package Clases;

/**
 *
 * @author STALIN
 */
public class OfertaAcademica {
    
    GradoParalelo idGradoParalelo;
    Materia idMateria;

    public OfertaAcademica() {
    }

    public OfertaAcademica(GradoParalelo idGradoParalelo, Materia idMateria) {
        this.idGradoParalelo = idGradoParalelo;
        this.idMateria = idMateria;
    }

    public GradoParalelo getIdGradoParalelo() {
        return idGradoParalelo;
    }

    public void setIdGradoParalelo(GradoParalelo idGradoParalelo) {
        this.idGradoParalelo = idGradoParalelo;
    }

    public Materia getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(Materia idMateria) {
        this.idMateria = idMateria;
    }
        
}
