/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Actividades;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Ricardo
 */
public class DataActividades extends Conexion {
    public Actividades BuscarActividad(Actividades ObjAux) {
        Actividades ObjAct = new Actividades();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM actividades WHERE Descripcion=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getDescripcion());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjAct.setAporteEconomico(rs.getDouble("aporteEconomico"));
                ObjAct.setDescripcion(rs.getString("Descripcion"));
                ObjAct.setFechaFinal(rs.getDate("FechaFinal"));
                ObjAct.setFechaInicio(rs.getDate("FechaInicio"));
                ObjAct.setSaldoActividades(rs.getDouble("saldoActividades"));
                ObjAct.setTipoActividad(rs.getString("tipoActividad"));
            }
            return ObjAct;
        } catch (Exception e) {
            System.err.println(e);
            return ObjAct;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public boolean InsertarActividad(Actividades ObjAct) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO actividades (tipoActividad, FechaInicio, FechaFinal, Descripcion, aporteEconomico, saldoActividades) VALUES (?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAct.getTipoActividad()); 
            ps.setDate(2, ObjAct.getFechaInicio());// FECHAS
            ps.setDate(3, ObjAct.getFechaFinal()); // FECHAS
            ps.setString(4, ObjAct.getDescripcion());
            ps.setDouble(5, ObjAct.getAporteEconomico());
            ps.setDouble(6, ObjAct.getSaldoActividades());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
