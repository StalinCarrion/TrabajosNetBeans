/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Clases.Actividades;
import Data.DataActividades;
/**
 *
 * @author Ricardo
 */
public class LogicaActividades {
    DataActividades objDatActividades = new DataActividades();

    public Actividades BuscarActividades(String descripcion) {
        Actividades ObjAct= new Actividades();
        ObjAct.setDescripcion(descripcion);
        ObjAct= objDatActividades.BuscarActividad(ObjAct);
        return ObjAct;
    }
    
    public boolean InsertarActividades (Actividades objAct){
        boolean x = objDatActividades.InsertarActividad(objAct);
        return x;
    }
}
