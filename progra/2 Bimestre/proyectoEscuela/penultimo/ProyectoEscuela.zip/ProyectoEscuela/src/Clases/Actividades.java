/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.sql.Date;



/**
 *
 * @author STALIN
 */
public class Actividades {
    String tipoActividad;
    Date FechaInicio;
    Date FechaFinal;
    String NombreActividad;
    double AporteEstudiante;

    public Actividades() {
    }

    public Actividades(String tipoActividad, Date FechaInicio, Date FechaFinal, String NombreActividad, double AporteEstudiante) {
        this.tipoActividad = tipoActividad;
        this.FechaInicio = FechaInicio;
        this.FechaFinal = FechaFinal;
        this.NombreActividad = NombreActividad;
        this.AporteEstudiante = AporteEstudiante;
    }

    public String getTipoActividad() {
        return tipoActividad;
    }

    public void setTipoActividad(String tipoActividad) {
        this.tipoActividad = tipoActividad;
    }

    public Date getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(Date FechaInicio) {
        this.FechaInicio = FechaInicio;
    }

    public Date getFechaFinal() {
        return FechaFinal;
    }

    public void setFechaFinal(Date FechaFinal) {
        this.FechaFinal = FechaFinal;
    }

    public String getNombreActividad() {
        return NombreActividad;
    }

    public void setNombreActividad(String NombreActividad) {
        this.NombreActividad = NombreActividad;
    }

    public double getAporteEstudiante() {
        return AporteEstudiante;
    }

    public void setAporteEstudiante(double AporteEstudiante) {
        this.AporteEstudiante = AporteEstudiante;
    }
    
}
