/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Materia {
    String idMateria;
    String nombreMateria;
    int horas;
    int idProfesor;
    GradoParalelo gradoParalelo;
    Profesor profesor;

    public Materia(String idMateria, String nombreMateria, int horas, int idProfesor) {
        this.idMateria = idMateria;
        this.nombreMateria = nombreMateria;
        this.horas = horas;
        this.idProfesor = idProfesor;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
    

    public GradoParalelo getGradoParalelo() {
        return gradoParalelo;
    }

    public void setGradoParalelo(GradoParalelo gradoParalelo) {
        this.gradoParalelo = gradoParalelo;
    }

    
    public String getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(String idMateria) {
        this.idMateria = idMateria;
    }
    
    
    public Materia() {
    }

    public Materia(String nombreMateria, int horas, int idProfesor) {
        this.nombreMateria = nombreMateria;
        this.horas = horas;
        this.idProfesor = idProfesor;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }
    
}
