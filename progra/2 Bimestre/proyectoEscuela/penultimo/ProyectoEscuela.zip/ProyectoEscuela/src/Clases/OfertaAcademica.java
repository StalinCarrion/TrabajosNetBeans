
package Clases;

/**
 *
 * @author STALIN
 */
public class OfertaAcademica {
    
    GradoParalelo idGradoParalelo;
    Materia idMateria;
    int idOfertaAcademica;
    

    public OfertaAcademica() {
    }

    public OfertaAcademica(GradoParalelo idGradoParalelo, Materia idMateria) {
        this.idGradoParalelo = idGradoParalelo;
        this.idMateria = idMateria;
    }

    public int getIdOfertaAcademica() {
        return idOfertaAcademica;
    }

    public void setIdOfertaAcademica(int idOfertaAcademica) {
        this.idOfertaAcademica = idOfertaAcademica;
    }
    

    public GradoParalelo getIdGradoParalelo() {
        return idGradoParalelo;
    }

    public void setIdGradoParalelo(GradoParalelo idGradoParalelo) {
        this.idGradoParalelo = idGradoParalelo;
    }

    public Materia getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(Materia idMateria) {
        this.idMateria = idMateria;
    }
        
}
