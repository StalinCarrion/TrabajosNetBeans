/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author FRANZ
 */
public class Profesor {
    String NombreProfesor;
    String ApellidoProfesor;
    String CedulaProfesor;
    String DireccionProfesor;
    String CorreoProfesor;
    String TelefonoProfesor;
    String idProfesor;

    public Profesor() {
    }

    public Profesor(String NombreProfesor, String ApellidoProfesor, String CedulaProfesor, String DireccionProfesor, String CorreoProfesor, String TelefonoProfesor, String idProfesor) {
        this.NombreProfesor = NombreProfesor;
        this.ApellidoProfesor = ApellidoProfesor;
        this.CedulaProfesor = CedulaProfesor;
        this.DireccionProfesor = DireccionProfesor;
        this.CorreoProfesor = CorreoProfesor;
        this.TelefonoProfesor = TelefonoProfesor;
        this.idProfesor = idProfesor;
    }

    public String getNombreProfesor() {
        return NombreProfesor;
    }

    public void setNombreProfesor(String NombreProfesor) {
        this.NombreProfesor = NombreProfesor;
    }

    public String getApellidoProfesor() {
        return ApellidoProfesor;
    }

    public void setApellidoProfesor(String ApellidoProfesor) {
        this.ApellidoProfesor = ApellidoProfesor;
    }

    public String getCedulaProfesor() {
        return CedulaProfesor;
    }

    public void setCedulaProfesor(String CedulaProfesor) {
        this.CedulaProfesor = CedulaProfesor;
    }

    public String getDireccionProfesor() {
        return DireccionProfesor;
    }

    public void setDireccionProfesor(String DireccionProfesor) {
        this.DireccionProfesor = DireccionProfesor;
    }

    public String getCorreoProfesor() {
        return CorreoProfesor;
    }

    public void setCorreoProfesor(String CorreoProfesor) {
        this.CorreoProfesor = CorreoProfesor;
    }

    public String getTelefonoProfesor() {
        return TelefonoProfesor;
    }

    public void setTelefonoProfesor(String TelefonoProfesor) {
        this.TelefonoProfesor = TelefonoProfesor;
    }

    public String getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(String idProfesor) {
        this.idProfesor = idProfesor;
    }
    
}
