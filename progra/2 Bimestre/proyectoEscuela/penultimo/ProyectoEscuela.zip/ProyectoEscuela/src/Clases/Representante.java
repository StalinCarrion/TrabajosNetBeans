
package Clases;

/**
 *
 * @author STALIN
 */
public class Representante{
      String NombreRepresentante;
      String ApellidoRepresentante;
      String Parentesco;
      String CedulaRepresentante;
      String DireccionRepresentante;
      String CorreoRepresentante;
      int idRepresentante;

    public Representante() {
    }

    public Representante(String NombreRepresentante, String ApellidoRepresentante, String Parentesco, String CedulaRepresentante, String DireccionRepresentante, String CorreoRepresentante, int idRepresentante) {
        this.NombreRepresentante = NombreRepresentante;
        this.ApellidoRepresentante = ApellidoRepresentante;
        this.Parentesco = Parentesco;
        this.CedulaRepresentante = CedulaRepresentante;
        this.DireccionRepresentante = DireccionRepresentante;
        this.CorreoRepresentante = CorreoRepresentante;
        this.idRepresentante = idRepresentante;
    }

    public String getNombreRepresentante() {
        return NombreRepresentante;
    }

    public String getApellidoRepresentante() {
        return ApellidoRepresentante;
    }

    public String getParentesco() {
        return Parentesco;
    }

    public String getCedulaRepresentante() {
        return CedulaRepresentante;
    }

    public String getDireccionRepresentante() {
        return DireccionRepresentante;
    }

    public String getCorreoRepresentante() {
        return CorreoRepresentante;
    }

    public int getIdRepresentante() {
        return idRepresentante;
    }

    public void setNombreRepresentante(String NombreRepresentante) {
        this.NombreRepresentante = NombreRepresentante;
    }

    public void setApellidoRepresentante(String ApellidoRepresentante) {
        this.ApellidoRepresentante = ApellidoRepresentante;
    }

    public void setParentesco(String Parentesco) {
        this.Parentesco = Parentesco;
    }

    public void setCedulaRepresentante(String CedulaRepresentante) {
        this.CedulaRepresentante = CedulaRepresentante;
    }

    public void setDireccionRepresentante(String DireccionRepresentante) {
        this.DireccionRepresentante = DireccionRepresentante;
    }

    public void setCorreoRepresentante(String CorreoRepresentante) {
        this.CorreoRepresentante = CorreoRepresentante;
    }

    public void setIdRepresentante(int idRepresentante) {
        this.idRepresentante = idRepresentante;
    }

    @Override
    public String toString() {
        return "Representante{" + "NombreRepresentante=" + NombreRepresentante + ", ApellidoRepresentante=" + ApellidoRepresentante + ", Parentesco=" + Parentesco + ", CedulaRepresentante=" + CedulaRepresentante + ", DireccionRepresentante=" + DireccionRepresentante + ", CorreoRepresentante=" + CorreoRepresentante + ", idRepresentante=" + idRepresentante + '}';
    }

    
    
}
