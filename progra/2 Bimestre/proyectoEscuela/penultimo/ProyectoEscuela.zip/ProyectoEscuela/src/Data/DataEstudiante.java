/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Estudiante;
import Clases.Representante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author FRANZ
 */
public class DataEstudiante extends Conexion{
    
    public Estudiante BuscarEstudiante(Estudiante ObjAux) {
        Estudiante ObjEstudiante = new Estudiante();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM estudiante WHERE cedula=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getCedulaEstudiante());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjEstudiante.setNombreEstudiante(rs.getString("nombre"));
                ObjEstudiante.setApellidoEstudiante(rs.getString("apellido"));                
                ObjEstudiante.setCedulaEstudiante(rs.getString("cedula"));
                ObjEstudiante.setDireccionEstudiante(rs.getString("direccion"));
                ObjEstudiante.setEdadEstudiante(rs.getInt("edad"));
                
            }
            return ObjEstudiante;
        } catch (Exception e) {
            System.err.println(e);
            return ObjEstudiante;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public boolean InsertarEstudiante(Estudiante ObjEstudiante) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO `escuela`.`estudiante` (`NombreEstudiante`, `ApellidoEstudiante`, `CedulaEstudiante`, `DireccionEstudiante`, `EdadEstudiante`,`idRepresentante`) VALUES (?,?,?,?,?,?)";
        try {
            Representante ObjRepresentante = new Representante();
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjEstudiante.getNombreEstudiante());
            ps.setString(2, ObjEstudiante.getApellidoEstudiante());
            ps.setString(3, ObjEstudiante.getCedulaEstudiante());
            ps.setString(4, ObjEstudiante.getDireccionEstudiante());
            ps.setInt(5, ObjEstudiante.getEdadEstudiante());
            ps.setInt(6, ObjEstudiante.getIdRepresentante());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
