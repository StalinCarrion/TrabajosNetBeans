/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.GradoParalelo;
import Clases.Materia;
import Clases.OfertaAcademica;
import Clases.Profesor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author STALIN
 */
public class DataOfertaAcademica extends Conexion {

    public ArrayList<Materia> BuscarOfertaAcademica(OfertaAcademica objOfertaAcademica) {
        ArrayList<Materia> arrayListMaterias = new ArrayList<Materia>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT idOferAcade, NombreMateria, Horas, Grado, Paralelo, NombreProfesor\n"
                + "FROM\n"
                + "\n"
                + "escuela.ofertaacademica,\n"
                + "escuela.materia,\n"
                + "escuela.gradoParalelo,\n"
                + "escuela.profesor\n"
                + "\n"
                + "where ofertaacademica.idGradoParalelo = gradoParalelo.idGradoParalelo\n"
                + "and ofertaacademica.idMateria = materia.idMateria\n"
                + "and materia.idProfesor = profesor.idProfesor\n"
                + "and gradoparalelo.Grado = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, objOfertaAcademica.getIdGradoParalelo().getGrado());
            rs = ps.executeQuery();
            while (rs.next()) {
                Materia objMateria = new Materia();
                GradoParalelo objGradoParalelo = new GradoParalelo();
                Profesor objProfesor = new Profesor();

                objMateria.setNombreMateria(rs.getString("NombreMateria"));
                objMateria.setHoras(rs.getInt("Horas"));
                objGradoParalelo.setGrado(rs.getInt("Grado"));
                objGradoParalelo.setParalelo(rs.getString("Paralelo"));
                objProfesor.setNombreProfesor(rs.getString("NombreProfesor"));
                objMateria.setGradoParalelo(objGradoParalelo);
                objMateria.setProfesor(objProfesor);
                arrayListMaterias.add(objMateria);
            }
            return arrayListMaterias;
        } catch (Exception e) {
            System.err.println(e);
            return arrayListMaterias;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public boolean InsertarOfertaAcademica(GradoParalelo objGradoParalelo, Materia objMateria) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO ofertaacademica (idGradoParalelo, idMateria) VALUES (?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, objGradoParalelo.getIdGradoParalelo());
            ps.setInt(2, Integer.parseInt(objMateria.getIdMateria()));

            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
