/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Representante;
import Clases.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author FRANZ
 */
public class DataRepresentante extends Conexion{
     public Representante BuscarRepresentante(Representante ObjAux) {
        Representante ObjRepresentante = new Representante();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM representante WHERE CedulaRepresentante=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getCedulaRepresentante());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjRepresentante.setNombreRepresentante(rs.getString("NombreRepresentante"));
                ObjRepresentante.setApellidoRepresentante(rs.getString("ApellidoRepresentante"));
                ObjRepresentante.setParentesco(rs.getString("Parentesco"));
                ObjRepresentante.setCedulaRepresentante(rs.getString("CedulaRepresentante"));
                ObjRepresentante.setDireccionRepresentante(rs.getString("DireccionRepresentante"));
                ObjRepresentante.setCorreoRepresentante(rs.getString("CorreoRepresentante"));
                ObjRepresentante.setIdRepresentante(rs.getInt("idRepresentante"));
            }
            return ObjRepresentante;
        } catch (Exception e) {
            System.err.println(e);
            return ObjRepresentante;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public boolean InsertarRepresentante(Representante ObjRepresentante) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO `escuela`.`Representante` (`NombreRepresentante`, `ApellidoRepresentante`, `Parentesco`, `CedulaRepresentante`, `DireccionRepresentante`, `CorreoRepresentante`) VALUES (?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjRepresentante.getNombreRepresentante());
            ps.setString(2, ObjRepresentante.getApellidoRepresentante());
            ps.setString(3, ObjRepresentante.getParentesco());
            ps.setString(4, ObjRepresentante.getCedulaRepresentante());
            ps.setString(5, ObjRepresentante.getDireccionRepresentante());
            ps.setString(6, ObjRepresentante.getCorreoRepresentante());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
