/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import sun.misc.Resource;

/**
 *
 * @author STALIN
 */
public class DataUsuario extends Conexion {

    public Usuario BuscarUsuario(Usuario ObjAux) {
        Usuario ObjUsuario = new Usuario();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM usuario WHERE usuario=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getUsuario());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjUsuario.setNombre(rs.getString("nombre"));
                ObjUsuario.setApellido(rs.getString("apellido"));
                ObjUsuario.setCedula(rs.getString("cedula"));
                ObjUsuario.setTelefono(rs.getString("telefono"));
                ObjUsuario.setDireccion(rs.getString("direccion"));
                ObjUsuario.setCorreo(rs.getString("correo"));
                ObjUsuario.setEdad(rs.getInt("edad"));
                ObjUsuario.setTipoUsuario(rs.getInt("tipoUsuario"));
                ObjUsuario.setUsuario(rs.getString("usuario"));
                ObjUsuario.setPass(rs.getString("pass"));
            }
            return ObjUsuario;
        } catch (SQLException e) {
            System.err.println(e);
            return ObjUsuario;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public boolean InsertarUsuario(Usuario ObjUsuario) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO usuario (NombreUsuario, ApellidoUsuario, CedulaUsuario, TelefonoUsuario, DireccionUsuario,"
                + " CorreoUsuario, EdadUsuario, TipoUsuario, Usuario, Pass) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjUsuario.getNombre());
            ps.setString(2, ObjUsuario.getApellido());
            ps.setString(3, ObjUsuario.getCedula());
            ps.setString(4, ObjUsuario.getTelefono());
            ps.setString(5, ObjUsuario.getDireccion());
            ps.setString(6, ObjUsuario.getCorreo());
            ps.setInt(7, ObjUsuario.getEdad());
            ps.setInt(8, ObjUsuario.getTipoUsuario());
            ps.setString(9, ObjUsuario.getUsuario());
            ps.setString(10, ObjUsuario.getPass());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
