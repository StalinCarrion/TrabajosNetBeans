/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Matricula {
    int numMatricula;
    String Fecha;
    Estudiante idEstudiante;
    OfertaAcademica idOfertaAcademica;

    public Matricula() {
    }

    public Matricula(int numMatricula, String Fecha, Estudiante idEstudiante, OfertaAcademica idOfertaAcademica) {
        this.numMatricula = numMatricula;
        this.Fecha = Fecha;
        this.idEstudiante = idEstudiante;
        this.idOfertaAcademica = idOfertaAcademica;
    }

    public int getNumMatricula() {
        return numMatricula;
    }

    public void setNumMatricula(int numMatricula) {
        this.numMatricula = numMatricula;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public Estudiante getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(Estudiante idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public OfertaAcademica getIdOfertaAcademica() {
        return idOfertaAcademica;
    }

    public void setIdOfertaAcademica(OfertaAcademica idOfertaAcademica) {
        this.idOfertaAcademica = idOfertaAcademica;
    }
    
}
