
package Clases;

/**
 *
 * @author STALIN
 */
public class OfertaAcademica {
    
    GradoParalelo GradoParalelo;
    Materia idMateria;
    int idOfertaAcademica;
    

    public OfertaAcademica() {
    }

    public OfertaAcademica(GradoParalelo idGradoParalelo, Materia idMateria) {
        this.GradoParalelo = idGradoParalelo;
        this.idMateria = idMateria;
    }

    public int getIdOfertaAcademica() {
        return idOfertaAcademica;
    }

    public void setIdOfertaAcademica(int idOfertaAcademica) {
        this.idOfertaAcademica = idOfertaAcademica;
    }
    

    public GradoParalelo getGradoParalelo() {
        return GradoParalelo;
    }

    public void setGradoParalelo(GradoParalelo GradoParalelo) {
        this.GradoParalelo = GradoParalelo;
    }

    public Materia getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(Materia idMateria) {
        this.idMateria = idMateria;
    }
        
}
