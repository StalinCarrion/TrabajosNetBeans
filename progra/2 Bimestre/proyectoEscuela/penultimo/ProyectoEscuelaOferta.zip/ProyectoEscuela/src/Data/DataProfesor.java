/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Profesor;
import Clases.Representante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author FRANZ
 */
public class DataProfesor extends Conexion{
    
    public ArrayList<Profesor> BuscarProfesor() {
        ArrayList<Profesor> ArrayPro = new ArrayList<Profesor>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "select NombreProfesor, ApellidoProfesor, CedulaProfesor, idProfesor from escuela.profesor";        
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Profesor ObjPro = new Profesor();
                ObjPro.setNombreProfesor(rs.getString("NombreProfesor"));
                ObjPro.setApellidoProfesor(rs.getString("ApellidoProfesor"));
                ObjPro.setCedulaProfesor(rs.getString("CedulaProfesor"));
                ObjPro.setIdProfesor(rs.getString("idProfesor"));
                ArrayPro.add(ObjPro);
            }
            return ArrayPro;
        } catch (Exception e) {
            System.err.println(e);
            return ArrayPro;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }  
    public boolean InsertarProfesor(Profesor ObjProfesor) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO `escuela`.`profesor` (`NombreProfesor`, `ApellidoProfesor`, `CedulaProfesor`, `DireccionProfesor`, `CorreoProfesor`, `TelefonoProfesor`) VALUES (?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjProfesor.getNombreProfesor());
            ps.setString(2, ObjProfesor.getApellidoProfesor());
            ps.setString(3, ObjProfesor.getCedulaProfesor());
            ps.setString(4, ObjProfesor.getDireccionProfesor());
            ps.setString(5, ObjProfesor.getCorreoProfesor());
            ps.setString(6, ObjProfesor.getTelefonoProfesor());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
    
    public Profesor BuscarProfesor(Profesor ObjAux) {
        Profesor ObjProfesor = new Profesor();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM profesor WHERE CedulaProfesor=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getCedulaProfesor());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjProfesor.setNombreProfesor(rs.getString("NombreProfesor"));
                ObjProfesor.setApellidoProfesor(rs.getString("ApellidoProfesor"));
                ObjProfesor.setCedulaProfesor(rs.getString("CedulaProfesor"));
                ObjProfesor.setDireccionProfesor(rs.getString("DireccionProfesor"));
                ObjProfesor.setCorreoProfesor(rs.getString("CorreoProfesor"));
                ObjProfesor.setTelefonoProfesor(rs.getString("TelefonoProfesor"));
            }
            return ObjProfesor;
        } catch (Exception e) {
            System.err.println(e);
            return ObjProfesor;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
    
}
