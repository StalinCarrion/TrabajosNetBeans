/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Clases.Estudiante;
import Data.DataEstudiante;

/**
 *
 * @author FRANZ
 */
public class LogicaEstudiante {
     DataEstudiante objDatEstudiante = new DataEstudiante();

    public Estudiante BuscarEstudiante(Estudiante objEstudiante) {
        objEstudiante = objDatEstudiante.BuscarEstudiante(objEstudiante);
        return objEstudiante;
    }
    
    public boolean InsertarEstudiante (Estudiante objEstudiante){
        boolean x = objDatEstudiante.InsertarEstudiante(objEstudiante);
        return x;
    }
}
