/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Facturacion {
    String nombreFacturacion;
    Double saldo;
    String descripcion;

    public Facturacion() {
    }

    public Facturacion(String nombreFacturacion, Double saldo, String descripcion) {
        this.nombreFacturacion = nombreFacturacion;
        this.saldo = saldo;
        this.descripcion = descripcion;
    }

    
    
}
