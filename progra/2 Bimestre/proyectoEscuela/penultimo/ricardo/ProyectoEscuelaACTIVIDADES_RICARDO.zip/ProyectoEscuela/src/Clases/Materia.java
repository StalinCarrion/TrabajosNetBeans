/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Materia {
    String nombreMateria;
    int horas;
    String profesor;

    public Materia() {
    }

    public Materia(String nombreMateria, int horas, String profesor) {
        this.nombreMateria = nombreMateria;
        this.horas = horas;
        this.profesor = profesor;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    @Override
    public String toString() {
        return "Materia{" + "nombreMateria=" + nombreMateria + ", horas=" + horas + ", profesor=" + profesor + '}';
    }

    
    
}
