/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Matricula {
    int nMatricula;
    String Fecha;
    Estudiante estudiante;
    Facturacion facturacion;
    
    Actividades actividades;
    Grado grado;
    //Composicion

    public Matricula(int nMatricula, String Fecha, Estudiante estudiante, Facturacion facturacion, Actividades actividades, Grado grado) {
        this.nMatricula = nMatricula;
        this.Fecha = Fecha;
        this.estudiante = estudiante;
        this.facturacion = facturacion;
        this.actividades = actividades;
        this.grado = grado;
    }
  
    
    
}
