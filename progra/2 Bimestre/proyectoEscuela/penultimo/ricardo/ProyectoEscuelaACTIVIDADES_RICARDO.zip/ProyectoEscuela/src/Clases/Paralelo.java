/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Paralelo {
    String nombreParalelo;
    String nEstudiantesParalelo;
    String tutor;

    public Paralelo() {
    }

    public Paralelo(String nombreParalelo, String nEstudiantes, String tutor) {
        this.nombreParalelo = nombreParalelo;
        this.nEstudiantesParalelo = nEstudiantesParalelo;
        this.tutor = tutor;
    }

    public String getNombreParalelo() {
        return nombreParalelo;
    }

    public void setNombreParalelo(String nombreParalelo) {
        this.nombreParalelo = nombreParalelo;
    }

    public String getnEstudiantesParalelo() {
        return nEstudiantesParalelo;
    }

    public void setnEstudiantesParalelo(String nEstudiantesParalelo) {
        this.nEstudiantesParalelo = nEstudiantesParalelo;
    }

    public String getTutor() {
        return tutor;
    }

    public void setTutor(String tutor) {
        this.tutor = tutor;
    }
    
    
    
    
}
