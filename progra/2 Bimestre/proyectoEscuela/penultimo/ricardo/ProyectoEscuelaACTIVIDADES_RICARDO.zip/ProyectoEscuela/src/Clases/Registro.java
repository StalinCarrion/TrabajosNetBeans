/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author STALIN
 */
public class Registro {
    String Fecha;
    Secretaria secretaria;
    Administrador administrador;
    Estudiante estudiante;
    Actividades actividades;

    public Registro() {
    }
    

    public Registro(String Fecha, Secretaria secretaria, Administrador administrador, Estudiante estudiante, Actividades actividades) {
        this.Fecha = Fecha;
        this.secretaria = secretaria;
        this.administrador = administrador;
        this.estudiante = estudiante;
        this.actividades = actividades;
    }
    
    
    
}
