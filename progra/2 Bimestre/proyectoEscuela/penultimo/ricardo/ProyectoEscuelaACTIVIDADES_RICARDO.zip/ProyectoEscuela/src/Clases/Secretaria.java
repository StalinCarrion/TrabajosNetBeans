
package Clases;

/**
 *
 * @author STALIN
 */
public class Secretaria extends Usuario{
    

    public Secretaria() {
    }

    public Secretaria(String tipoUsuario, String usuario, String pass) {
        super(tipoUsuario, usuario, pass);
    }
    
    
}
