/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Clases.Actividades;
import Clases.Estudiante;
import Clases.Grado;
import Clases.Paralelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ricardo
 */
public class DataAlumnos extends Conexion {

    public Estudiante BuscarAlumno(Estudiante ObjAux) {
        Estudiante ObjEstudiante = new Estudiante();
        Grado ObjGrado = new Grado();
        Paralelo ObjParalelo = new Paralelo();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT estudiante.idEstudiante,estudiante.NombreEstudiante, estudiante.ApellidoEstudiante, gradoparalelo.Grado, gradoparalelo.Paralelo FROM escuela.estudiante, escuela.gradoparalelo WHERE  gradoparalelo.idGradoParalelo = idEstudiante and estudiante.CedulaEstudiante = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getCedula());
            System.out.println(ObjAux.getCedula());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjEstudiante.setIdEstudiante(rs.getInt("idEstudiante"));
                ObjEstudiante.setNombre(rs.getString("NombreEstudiante"));
                ObjEstudiante.setApellido(rs.getString("ApellidoEstudiante"));
                ObjGrado.setNombreGrado(rs.getString("Grado"));
                ObjParalelo.setNombreParalelo(rs.getString("Paralelo"));
            }
            ObjEstudiante.setGrado(ObjGrado);
            ObjGrado.setParalelo(ObjParalelo);
            return ObjEstudiante;
        } catch (Exception e) {
            System.err.println(e);
            return ObjEstudiante;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }

    public ArrayList<Estudiante> BuscarAlumnoActividad(Actividades ObjAux) {
        ArrayList<Estudiante> ArrayEstudiante = new ArrayList<Estudiante>();

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT idActividadesEstudiante, NombreEstudiante, ApellidoEstudiante, NombreActividad, Grado, Paralelo\n"
                + "FROM\n"
                + "\n"
                + "escuela.actividadesestudiante,\n"
                + "escuela.estudiante,\n"
                + "escuela.actividades,\n"
                + "escuela.matricula,\n"
                + "escuela.ofertaacademica, \n"
                + "escuela.gradoparalelo\n"
                + "\n"
                + "where actividadesestudiante.idActividad = actividades.idActividad\n"
                + "and actividadesestudiante.idEstudiante = estudiante.idEstudiante\n"
                + "and matricula.idOferAcade = ofertaacademica.idOferAcade\n"
                + "and matricula.idEstudiante = estudiante.idEstudiante\n"
                + "and ofertaacademica.idGradoParalelo = gradoparalelo.idGradoParalelo\n"
                + "and gradoparalelo.paralelo = gradoparalelo.paralelo\n"
                + "and actividadesestudiante.idActividad = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, ObjAux.getIdActividad());
            rs = ps.executeQuery();
            while (rs.next()) {
                Estudiante ObjEstudiante = new Estudiante();
                Grado ObjGrado = new Grado();
                Paralelo ObjParalelo = new Paralelo();
                ObjEstudiante.setIdEstudiante(rs.getInt("idActividadesEstudiante")); // Se setea en el idEstudiante el idActividadesEstudiante
                ObjEstudiante.setNombre(rs.getString("NombreEstudiante"));
                ObjEstudiante.setApellido(rs.getString("ApellidoEstudiante"));
                ObjGrado.setNombreGrado(rs.getString("Grado"));
                ObjParalelo.setNombreParalelo(rs.getString("Paralelo"));
                ObjEstudiante.setGrado(ObjGrado);
                ObjGrado.setParalelo(ObjParalelo);
                ArrayEstudiante.add(ObjEstudiante);
            }

            return ArrayEstudiante;
        } catch (Exception e) {
            System.err.println(e);
            return ArrayEstudiante;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
