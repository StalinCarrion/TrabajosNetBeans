/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;
import Clases.Paralelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import sun.misc.Resource;

/**
 *
 * @author STALIN
 */
public class DataParalelo extends Conexion{
    public Paralelo BuscarParalelo(Paralelo ObjAux){
        Paralelo ObjParalelo = new Paralelo();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection con = getConexion();
        String sql = "SELECT * FROM paralelo WHERE nombreParalelo=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjAux.getNombreParalelo());
            rs = ps.executeQuery();
            if (rs.next()) {
                ObjParalelo.setNombreParalelo(rs.getString("nombreParalelo"));
                ObjParalelo.setnEstudiantesParalelo(rs.getString("nEstudiantesParalelo"));
                ObjParalelo.setTutor(rs.getString("tutor")); 

            }
            return ObjParalelo;
        } catch (Exception e) {
            System.err.println(e);
            return ObjParalelo;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
    
    public boolean InsertarParalelo(Paralelo ObjParalelo) {
        PreparedStatement ps = null;
        Connection con = getConexion();
        String sql = "INSERT INTO paralelo (nombreParalelo, nEstudiantesParalelo, tutor) VALUES (?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ObjParalelo.getNombreParalelo());
            ps.setString(2, ObjParalelo.getnEstudiantesParalelo());
            ps.setString(3, ObjParalelo.getTutor());
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(3);
            }
        }
    }
}
