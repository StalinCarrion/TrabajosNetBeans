/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Clases.Actividades;
import Clases.Estudiante;
import Data.DataAlumnos;
import java.util.ArrayList;

/**
 *
 * @author Ricardo
 */
public class LogicaAlumnos {

    DataAlumnos ObjDatAlumnos = new DataAlumnos();

    public Estudiante BuscarEstudiante(Estudiante ObjAux) {
        Estudiante ObjEst = new Estudiante();
        ObjEst = ObjDatAlumnos.BuscarAlumno(ObjAux);
        return ObjEst;
    }
    public ArrayList<Estudiante> BuscarEstudianteActividad(Actividades ObjAct){
        ArrayList<Estudiante> ArrayAlumnos = new ArrayList<Estudiante>();
        ArrayAlumnos = ObjDatAlumnos.BuscarAlumnoActividad(ObjAct);
        
        return ArrayAlumnos;
    }
}
