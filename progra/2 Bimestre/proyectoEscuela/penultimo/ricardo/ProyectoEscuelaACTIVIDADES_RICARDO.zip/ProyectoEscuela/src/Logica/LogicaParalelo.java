/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Clases.Paralelo;
import Data.DataParalelo;

/**
 *
 * @author STALIN
 */
public class LogicaParalelo {

    DataParalelo objDatParalelo = new DataParalelo();

    public Paralelo BuscarParalelo(String nombreParalelo) {
        Paralelo objParalelo = new Paralelo();
        objParalelo.setNombreParalelo(nombreParalelo);
        objParalelo = objDatParalelo.BuscarParalelo(objParalelo);
        return objParalelo;
    }
    
    public boolean InsertarParalelo (Paralelo objParalelo){
        boolean x = objDatParalelo.InsertarParalelo(objParalelo);
        return x;
    }
}
