
package Logica;

/**
 *
 * @author Salas
 */
public class Transaccion {
 
    
}
